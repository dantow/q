package com.rmnnorbert.VATCalculator.dto;

import java.util.ArrayList;
public record VatRateListResponse(ArrayList<Integer> vatRateList) {
}
