package com.rmnnorbert.VATCalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VatCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
