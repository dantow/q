# VAT-Calculator

The VAT Calculator API is designed to provide seamless calculation of Net, Gross, and VAT amounts for purchases.
It offers a convenient solution for businesses and individuals to accurately compute purchase data based on provided information.

Used technologies:
* Java 17 (Maven)
* Spring Boot
* springdoc-openapi